# terraform-provider-minecraft

This repo utilizes the [go-minecraft](https://github.com/scottwinkler/go-minecraft) sdk and the [terraform-minecraft-plugin](https://github.com/scottwinkler/terraform-minecraft-plugin)